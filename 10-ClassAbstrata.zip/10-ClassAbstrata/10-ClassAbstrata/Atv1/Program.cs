﻿namespace _10_ClassAbstrata.Atv1
{
    internal class Program
    {
        //static void Main(string[] args)
        //{
        //    Aluno aluno = new Aluno()
        //    {
        //        Nome = "Carlos",
        //        Idade = 20,
        //        Matricula = "A1234"
        //    };

        //    Professor professor = new Professor()
        //    {
        //        Nome = "Guilherme",
        //        Idade = 45,
        //        Disciplina = "Matemática"
        //    };

        //    aluno.Apresentar();
        //    professor.Apresentar();
        //}
    }
}
