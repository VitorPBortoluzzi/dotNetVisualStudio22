﻿namespace _10_ClassAbstrata.Atv3
{
    internal class Program
    {
        //static void Main(string[] args)
        //{
        //    ContaCorrente cc = new ContaCorrente();
        //    cc.Depositar(1000);
        //    cc.Sacar(200);

        //    Console.WriteLine();

        //    ContaPoupanca cp = new ContaPoupanca();
        //    cp.Depositar(500);
        //    cp.Sacar(100);
        //}
    }
}
